/* Exercise 06

This challenge activitiy should ask for the following inputs:
- a basketball player's name
- average points per game
- height in inches

and then display the player name, average points per game, 
and height in ft and inches

There are 12 inches in 1 ft. so 75 inches is 6ft 3 inches

 */
package basketballplayer;
import java.util.*;

/**
 *
 * @author onadc
 */
public class BasketballPlayer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        
        int point;
        int setHeight;
        
        System.out.print("Enter the player's name: ");  
        String name = sc.nextLine();        
        System.out.print("Average points per game: ");  
        point = sc.nextInt();
        System.out.print("Enter player's height(in inches): ");  
        setHeight = sc.nextInt();
        
        int feet = setHeight / 12;
        int inch = setHeight % 12;
        
        System.out.println("Player's name: " + name);
        System.out.println("Average Points per Game: " + point);
        System.out.println(name + "'s height: " + feet + "ft. and " + inch + " inch");
    }
    
}
