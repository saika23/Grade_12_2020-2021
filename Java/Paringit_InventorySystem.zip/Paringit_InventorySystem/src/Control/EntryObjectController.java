/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;
import java.sql.*;
import Model.Entry;
import java.util.*;

/**
 *
 * @author Entry
 */
public class EntryObjectController {
    
    private Connection conn;
    private PreparedStatement pstm;
    
    public void connect(){
        try {
            conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1/evernotedb","root","");
        } catch(Exception e) {
            System.out.println("Connection failed: " + e);
        }
    }
    
    public boolean newEntry(Entry u) {
        boolean isSuccessful = true;
        connect();
        String insertQuery = "INSERT INTO tbl_entries (title, content) VALUES (?, ?)";
        try {
            pstm = conn.prepareStatement(insertQuery);
            pstm.setString(1, u.getTitle());
            pstm.setString(2, u.getContent());
            pstm.executeUpdate();
        } catch (Exception e) {
            System.out.println("Insert failed: " + e);
            isSuccessful = false;
        }
        return isSuccessful;
    }
    
    public boolean editEntry(Entry u) {
        boolean isSuccessful = true;
        connect();
        String insertQuery = "UPDATE tbl_entries SET title = ?, content = ? WHERE id = ?";
        try {
            pstm = conn.prepareStatement(insertQuery);
            pstm.setString(1, u.getTitle());
            pstm.setString(2, u.getContent());
            pstm.setInt(3, u.getId());
            pstm.executeUpdate();
        } catch (Exception e) {
            System.out.println("Insert failed: " + e);
            isSuccessful = false;
        }
        return isSuccessful;
    }
    
    public boolean deleteEntry(Entry u) {
        boolean isSuccessful = true;
        connect();
        String insertQuery = "DELETE FROM tbl_entries WHERE id = ?";
        try {
            pstm = conn.prepareStatement(insertQuery);
            pstm.setInt(1, u.getId());
            pstm.executeUpdate();
        } catch (Exception e) {
            System.out.println("Delete failed: " + e);
            isSuccessful = false;
        }
        return isSuccessful;
    }
    
    public ArrayList<Entry> displayEntries() {
        connect();
        String insertQuery = "Select * from tbl_entries";
        ArrayList<Entry> entryList = new ArrayList();
        Entry u = null;
        ResultSet rs = null;
        try {
            pstm = conn.prepareStatement(insertQuery);
            rs = pstm.executeQuery();
            while(rs.next()) {
                u = new Entry(rs.getInt("id"), rs.getString("title"), rs.getString("content"), rs.getString("datetime"));
                entryList.add(u);
            }
        } catch (Exception e) {
            System.out.println("Display failed: " + e);
        }
        return entryList;
    }
    
    public Entry displaySpecificEntry(Entry u) {
        connect();
        String insertQuery = "Select * from tbl_entries WHERE id = ?";
        ResultSet rs = null;
        try {
            pstm = conn.prepareStatement(insertQuery);
            pstm.setInt(1, u.getId());
            rs = pstm.executeQuery();
            rs.next();
            u = new Entry(rs.getInt("id"), rs.getString("title"), rs.getString("content"), rs.getString("datetime"));
        } catch (Exception e) {
            System.out.println("Display failed: " + e);
        }
        return u;
    }
    
    public boolean entryExists(Entry u) {
        boolean userExists = false;
        
        connect();
        String insertQuery = "Select id from tbl_entries";
        ResultSet rs = null;
        try {
            pstm = conn.prepareStatement(insertQuery);
            rs = pstm.executeQuery();
            while(rs.next()){
                if(u.getId() == rs.getInt("id")) {
                    userExists = true;
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println("Id not found: " + e);
        }
        return userExists;
    }
}
