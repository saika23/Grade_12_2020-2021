/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Entry
 */
public class Entry {
    
    private int id;
    private String title;
    private String content;
    private String timestamp;
    
    public Entry(int id, String title, String content, String address) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.timestamp = address;
    }

    public Entry(String title, String content, String address) {
        this.title = title;
        this.content = content;
        this.timestamp = address;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public String getTimestamp() {
        return timestamp;
    }
    
}
