/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;
import Control.EntryObjectController;
import Model.Entry;
import java.io.*;
import java.util.*;
/**
 *
 * @author Entry
 */
public class Main {
    public static void main(String[] args) throws Exception {
        int choice = 0;
        EntryObjectController c = new EntryObjectController();
        Entry u = new Entry("", "","");
        BufferedReader br =  new BufferedReader(new InputStreamReader(System.in));
        
        do{
            System.out.print("--------------------\n\n");
            System.out.println("Ever note");
            System.out.println("[1] Display All Entries");
            System.out.println("[2] Display Specific Entry");
            System.out.println("[3] Add Entry");
            System.out.println("[4] Edit Entry");
            System.out.println("[5] Delete Entry");
            System.out.println("[6] Exit");
            System.out.print("Choice: ");
            
            try {
                choice = Integer.parseInt(br.readLine());
                System.out.print("\n--------------------\n");
            } 
            catch (IOException | NumberFormatException e) {
                System.out.println("Invalid input, please use integers to select.");
                System.out.println("Errors: " + e);
                continue;
            }
            
            switch(choice) {
                case 1: //display all users
                    System.out.println("Display Entries");
                    ArrayList<Entry> entryList = c.displayEntries();
                    if(entryList != null) {
                        for (Entry ua : entryList) {
                            System.out.println("Id: " + ua.getId());
                            System.out.println("Title: " + ua.getTitle());
                            System.out.println("Content: " + ua.getContent());
                            System.out.println("Timestamp: " + ua.getTimestamp() + "\n");
                        }
                    } else {
                        System.out.println("No entries found.");
                    }
                    break;
                case 2:
                    System.out.println("Display Specific Entry");
                    try {
                        System.out.print("Id: ");
                        u.setId(Integer.parseInt(br.readLine().trim()));
                        if(!c.entryExists(u)) {
                            System.out.println("No entry found.");
                            break;
                        }
                    } catch (Exception e) {
                        System.out.print("\n--------------------\n");
                        System.out.println("Errors: " + e);
                        break; 
                    }
                    Entry ud = c.displaySpecificEntry(u);
                    if(ud != null) {
                        System.out.println("Id: " + ud.getId());
                        System.out.println("Title: " + ud.getTitle());
                        System.out.println("Content: " + ud.getContent());
                        System.out.println("Timestamp: " + ud.getTimestamp());
                    }
                    break;
                case 3: //add entry
                    System.out.println("Add Entry");
                    try {
                        System.out.print("Title: ");
                        u.setTitle(br.readLine());
                        System.out.print("Content: ");
                        u.setContent(br.readLine());
                    } catch (Exception e) {
                        System.out.println("Errors: " + e);
                        break;
                    }
                    if(c.newEntry(u)) {
                        System.out.print("\n--------------------\n");
                        System.out.println("Entry added");
                    } else {
                        System.out.print("\n--------------------\n");
                        System.out.println("Failed to add entry");
                    }
                    break;
                case 4: //edit entry
                    System.out.println("Edit Entry");
                    try {
                        System.out.print("Id: ");
                        u.setId(Integer.parseInt(br.readLine().trim()));
                        if(!c.entryExists(u)) {
                            System.out.println("Id not found");
                            break;
                        }
                        System.out.print("Title: ");
                        u.setTitle(br.readLine());
                        System.out.print("Content: ");
                        u.setContent(br.readLine());
                    } catch (Exception e) {
                        System.out.print("\n--------------------\n");
                        System.out.println("Errors: " + e);
                        break;
                    }
                    if(c.editEntry(u)) {
                        System.out.println("Entry edited");
                    } else {
                        System.out.println("Failed to edit entry");
                    }
                    break;
                case 5: //delete entry
                    System.out.println("\nDelete Entry");
                    try {
                        System.out.print("Id: ");
                        u.setId(Integer.parseInt(br.readLine().trim()));
                        if(!c.entryExists(u)) {
                            System.out.println("Id not found");
                            break;
                        }
                    } catch (Exception e) {
                        System.out.print("\n--------------------\n");
                        System.out.println("Errors: " + e);
                        break;
                    }
                    if(c.deleteEntry(u)) {
                        System.out.println("Entry deleted");
                    } else {
                        System.out.println("Failed to delete entry");
                    }
                    break;
                case 6:
                    System.out.println("Goodbye");
                    break;
                default:
                    System.out.println("Invalid choice");
            }
        } while(choice != 6);
        
    }
}
