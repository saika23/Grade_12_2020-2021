/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package method;

/**
 *
 * @author xyrus
 */

import java.io.*;

public class Method {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int opt = 0;
        
        do{
            System.out.println("[1] Addition");
            System.out.println("[2] Subtraction");
            System.out.println("[3] Multiplication");
            System.out.println("[4] Division");
            System.out.println("[5] Exit");
            System.out.print("Choose an option: ");
            opt = Integer.parseInt(br.readLine());
            
            switch(opt){
                case 1:
                    addition();
                    break;
                    
                case 2:
                    double diff = 0;
                    diff = subtraction();
                    System.out.println("The difference is " + diff);
                    break;
                    
                case 3:
                    double num1 = 0, num2 = 0;
                    System.out.print("Enter first number: ");
                    num1 = Double.parseDouble(br.readLine());
                    System.out.print("Enter second number: ");
                    num2 = Double.parseDouble(br.readLine());
                    
                    multiplication(num1, num2);
                    break;
                    
                case 4:
                    double num11 = 0, num22 = 0, quo = 0;
                    System.out.print("Enter first number: ");
                    num11 = Double.parseDouble(br.readLine());
                    System.out.print("Enter second number: ");
                    num22 = Double.parseDouble(br.readLine());
                    
                    quo = division(num11, num22);
                    
                    System.out.println("The quotient is " + quo);
                    break;
                    
                case 5:
                    System.out.println("Good bye.");
                    break;
                    
                default:
                    System.out.println("Invalid option.");
            }
        }while(opt != 5);
    }
    
    public static void addition() throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        double num1 = 0, num2 = 0, sum = 0;
        
        System.out.print("Enter first number: ");
        num1 = Double.parseDouble(br.readLine());
        System.out.print("Enter second number: ");
        num2 = Double.parseDouble(br.readLine());
        
        sum = num1 + num2;
        
        System.out.println("The sum is " + sum);
    }
    
    public static double subtraction() throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        double num1 = 0, num2 = 0, diff = 0;
        
        System.out.print("Enter first number: ");
        num1 = Double.parseDouble(br.readLine());
        System.out.print("Enter second number: ");
        num2 = Double.parseDouble(br.readLine());
        
        diff = num1 - num2;
        
        return diff;
    }
    
    public static void multiplication(double num1, double num2){
        double prod = 0;
        prod = num1 * num2;
        
        System.out.println("The product is " + prod);
    }
    
    public static double division(double num1, double num2){
        double quo = 0;
        quo = num1 / num2;
        
        return quo;
    }
}