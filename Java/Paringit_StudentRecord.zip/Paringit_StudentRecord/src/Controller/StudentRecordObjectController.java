/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.StudentRecord;
import java.sql.*;
import java.util.ArrayList;

public class StudentRecordObjectController {
    private Connection conn;
    private PreparedStatement pstm;
    
    public void establishConnection() {
        try {
            this.conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1/studentrecorddb", "root", "");
        }
        catch(Exception ex) {
            System.out.println("Can't establish connection. " + ex);
        }
    }
    
    public ArrayList<StudentRecord> viewAllStudents(int teacherId) {
        this.establishConnection();
        
        ArrayList<StudentRecord> studentList = new ArrayList<>();
        StudentRecord s = null;
        ResultSet rs = null;
        
        String query = "SELECT * FROM tbl_students WHERE teacher_id = ?";
        
        try {
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setInt(1, teacherId);
            rs = this.pstm.executeQuery();
            
            while(rs.next()) {
                String studentId = rs.getString("student_id");
                String name = rs.getString("name");
                double grade = rs.getDouble("grade");
                
                s = new StudentRecord(studentId, name, grade);
                
                studentList.add(s);
            }
        }
        catch(Exception ex) {
            System.out.println("Can't view items. " + ex);
        }
        
        return studentList;
    }
    
    public StudentRecord viewSpecificStudent(String studentId, int teacherId) {
        this.establishConnection();
        StudentRecord s = null;
        ResultSet rs = null;
        String query = "SELECT * FROM tbl_students WHERE student_id = ? AND teacher_id = ?";
        
        try {
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, studentId);
            this.pstm.setInt(2, teacherId);
            
            rs = this.pstm.executeQuery();
            
            rs.next();
            
            studentId = rs.getString("student_id");
            String name = rs.getString("name");
            double grade = rs.getDouble("grade");
            
            s = new StudentRecord(studentId, name, grade);
        }
        catch(Exception ex) {
            System.out.println("Can't view specific item. " + ex);
        }
        
        return s;
    }
    
    public boolean addStudent(StudentRecord s) {
        this.establishConnection();
        boolean success = false;
        
        String query = "INSERT INTO tbl_students(student_id, name, grade, teacher_id) VALUES(?, ?, ?, ?)";
        
        try {
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, s.getStudentId());
            this.pstm.setString(2, s.getName());
            this.pstm.setDouble(3, s.getGrade());
            this.pstm.setInt(4, s.getTeacherId());
            
            if(!s.getStudentId().isEmpty() && !s.getName().isEmpty()) {
                this.pstm.executeUpdate();
                success = true;
            }
        }
        catch(Exception ex) {
            System.out.println("Can't add student. " + ex);
        }
        
        return success;
    }
    
    public boolean editStudent(StudentRecord s, String studentId, int teacherId) {
        this.establishConnection();
        boolean success = false;
        
        String query = "UPDATE tbl_students SET student_id = ?, name = ?, grade = ? WHERE student_id = ? AND teacher_id = ?";
        
        try {
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, s.getStudentId());
            this.pstm.setString(2, s.getName());
            this.pstm.setDouble(3, s.getGrade());
            this.pstm.setString(4, studentId);
            this.pstm.setInt(5, teacherId);
            
            if(!s.getStudentId().isEmpty() && !s.getName().isEmpty()) {
                this.pstm.executeUpdate();
                success = true;
            }
        }
        catch (Exception ex) {
            System.out.println("Can't update student. " + ex);
        }
        
        return success;
    }
    
    public boolean removeStudent(String studentId, int teacherId) {
        this.establishConnection();
        boolean success = false;
        
        String query = "DELETE FROM tbl_students WHERE student_id = ? AND teacher_id = ?";
        
        try {
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, studentId);
            this.pstm.setInt(2, teacherId);
            
            this.pstm.executeUpdate();
            success = true;
        }
        catch(Exception ex) {
            System.out.println("Can't delete student. " + ex);
        }
        
        return success;
    }
    
    public boolean idChecker(String studentId) {
        this.establishConnection();
        boolean exist = false;
        ResultSet rs = null;
        
        String query = "SELECT student_id FROM tbl_students WHERE student_id = ?";
        
        try {
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, studentId);
            
            rs = this.pstm.executeQuery();
            
            if(rs.next() == false) {
                exist = false;
            } else {
                exist = true;
            }
        }
        catch(Exception ex) {
            System.out.println("Error: " + ex);
        }
        
        return exist;
    }
    
    public boolean idCheckerEdit(String studentId, String holderStudentId) {
        this.establishConnection();
        boolean exist = false;
        ResultSet rs = null;
        
        if(studentId.equals(holderStudentId)) {
            exist = false;
        } else {
            String query = "SELECT student_id FROM tbl_students WHERE student_id = ?";
        
            try {
                this.pstm = this.conn.prepareStatement(query);
                this.pstm.setString(1, studentId);

                rs = this.pstm.executeQuery();

                if(rs.next() == false) {
                    exist = false;
                } else {
                    exist = true;
                }
            }
            catch(Exception ex) {
                System.out.println("Error: " + ex);
            }
        }   
        return exist;
    }
}
