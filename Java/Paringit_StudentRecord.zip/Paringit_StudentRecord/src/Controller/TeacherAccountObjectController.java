/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.TeacherAccount;
import java.sql.*;

public class TeacherAccountObjectController {
    private Connection conn;
    private PreparedStatement pstm;
    
    public void establishConnection() {
        try {
            this.conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1/studentrecorddb", "root", "");
        }
        catch(Exception ex) {
            System.out.println("Can't establish connection. " + ex);
        }
    }
    
    public boolean addTeacher(TeacherAccount t) {
        this.establishConnection();
        boolean success = false;
        
        String query = "INSERT INTO tbl_teachers(name, username, password) VALUES(?, ?, ?)";
        
        try {
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, t.getName());
            this.pstm.setString(2, t.getUsername());
            this.pstm.setString(3, t.getPassword());
            
            if(!t.getName().isEmpty() && !t.getUsername().isEmpty() && !t.getPassword().isEmpty()) {
                this.pstm.executeUpdate();
                success = true;
            }
        }
        catch(Exception ex) {
            System.out.println("Can't add account. " + ex);
        }
        
        return success;
    }
    
    public boolean nameChecker(String registerUsername) {
        this.establishConnection();
        boolean exist = false;
        ResultSet rs = null;
        
        String query = "SELECT username FROM tbl_teachers WHERE username = ?";
        
        try {
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, registerUsername);
            
            rs = this.pstm.executeQuery();
            
            if(rs.next() == false) {
                exist = false;
            } else {
                exist = true;
            }
        }
        catch(Exception ex) {
            System.out.println("Error: " + ex);
        }
        
        return exist;
    }
    
    public int teacherLogin(TeacherAccount t) {
        this.establishConnection();
        int teacherId = 0;
        ResultSet rs = null;
        
        String query = "SELECT id FROM tbl_teachers WHERE username = ? AND password = ?";
        
        try {
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setString(1, t.getUsername());
            this.pstm.setString(2, t.getPassword());
            
            rs = this.pstm.executeQuery();
            
            if(rs.next() == false) {
                teacherId = 0;
            } else {
                teacherId = rs.getInt("id");
            }
        }
        catch(Exception ex) {
            System.out.println("Error: " + ex);
        }
        
        return teacherId;
    }
}
