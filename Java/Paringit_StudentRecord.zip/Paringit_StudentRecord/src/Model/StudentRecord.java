/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

public class StudentRecord {
    private int id;
    private String studentId;
    private String name;
    private double grade;
    private int teacherId;

    public StudentRecord(int id, String studentId, String name, double grade, int teacherId) {
        this.id = id;
        this.studentId = studentId;
        this.name = name;
        this.grade = grade;
        this.teacherId = teacherId;
    }

    public StudentRecord(String studentId, String name, double grade, int teacherId) {
        this.studentId = studentId;
        this.name = name;
        this.grade = grade;
        this.teacherId = teacherId;
    }

    public StudentRecord(String studentId, String name, double grade) {
        this.studentId = studentId;
        this.name = name;
        this.grade = grade;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }

    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }

    public int getId() {
        return id;
    }

    public String getStudentId() {
        return studentId;
    }

    public String getName() {
        return name;
    }

    public double getGrade() {
        return grade;
    }

    public int getTeacherId() {
        return teacherId;
    }
}
