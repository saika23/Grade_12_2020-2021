/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.*;
import model.Students;
import java.util.*;
/**
 *
 * @author Desktop
 */
public class StudentsObjectController {
    private Connection conn;
    private PreparedStatement pstm;
    
    public void connect(){
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/studentrecorddb","root","");
        } catch(Exception e) {
            System.out.println("Connection failed: " + e);
        }
    }
    
    public boolean newStudent(Students u, int teacher_id) {
        boolean isSuccessful = true;
        connect();
        String insertQuery = "INSERT INTO tbl_students (name, student_id, grade, teacher_id) VALUES (?, ?, ?, ?)";
        try {
            pstm = conn.prepareStatement(insertQuery);
            pstm.setString(1, u.getName());
            pstm.setInt(2, u.getStudent_id());
            pstm.setDouble(3, u.getGrade());
            pstm.setInt(4, teacher_id);
            pstm.executeUpdate();
        } catch (Exception e) {
            System.out.println("Insert failed: " + e);
            isSuccessful = false;
        }
        return isSuccessful;
    }
    
    public boolean editStudent(Students u, int tId) {
        boolean isSuccessful = true;
        connect();
        String insertQuery = "UPDATE tbl_students SET name = ?, student_id = ?, grade = ? WHERE id = ? AND teacher_id = ?";
        try {
            pstm = conn.prepareStatement(insertQuery);
            pstm.setString(1, u.getName());
            pstm.setInt(2, u.getStudent_id());
            pstm.setDouble(3, u.getGrade());
            pstm.setInt(4, u.getId());
            pstm.setInt(5, tId);
            pstm.executeUpdate();
        } catch (Exception e) {
            System.out.println("Insert failed: " + e);
            isSuccessful = false;
        }
        return isSuccessful;
    }
    
    public boolean deleteStudent(Students u, int tId) {
        boolean isSuccessful = true;
        connect();
        String insertQuery = "DELETE FROM tbl_students WHERE id = ? AND teacher_id = ?";
        try {
            pstm = conn.prepareStatement(insertQuery);
            pstm.setInt(1, u.getId());
            pstm.setInt(2, tId);
            pstm.executeUpdate();
        } catch (Exception e) {
            System.out.println("Delete failed: " + e);
            isSuccessful = false;
        }
        return isSuccessful;
    }
    
    public ArrayList<Students> displayStudent(int tId) {
        connect();
        String insertQuery = "Select * from tbl_students WHERE teacher_id = ?";
        ArrayList<Students> entryList = new ArrayList();
        Students u = null;
        ResultSet rs = null;
        try {
            pstm = conn.prepareStatement(insertQuery);
            pstm.setInt(1, tId);
            rs = pstm.executeQuery();
            while(rs.next()) {
                u = new Students(rs.getInt("id"), rs.getInt("student_id"), rs.getString("name"), rs.getDouble("grade"), rs.getInt("student_id"));
                entryList.add(u);
            }
        } catch (Exception e) {
            System.out.println("Display failed: " + e);
        }
        return entryList;
    }
    
    public Students displaySpecificStudent(Students u, int tId) {
        connect();
        String insertQuery = "Select * from tbl_students WHERE student_id = ? AND teacher_id = ?";
        ResultSet rs = null;
        try {
            pstm = conn.prepareStatement(insertQuery);
            pstm.setInt(1, u.getStudent_id());
            pstm.setInt(2, tId);
            rs = pstm.executeQuery();
            rs.next();
           u = new Students(rs.getInt("id"), rs.getInt("student_id"), rs.getString("name"), rs.getDouble("grade"), rs.getInt("teacher_id"));
        } catch (Exception e) {
            System.out.println("Display failed: " + e);
        }
        return u;
    }
    
    public boolean StudentExists(Students u) {
        boolean entryExists = false;
        
        connect();
        String insertQuery = "Select student_id from tbl_students";
        ResultSet rs = null;
        try {
            pstm = conn.prepareStatement(insertQuery);
            rs = pstm.executeQuery();
            while(rs.next()){
                if(u.getStudent_id() == rs.getInt("student_id")) {
                    entryExists = true;
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println("Id not found: " + e);
        }
        return entryExists;
    }
    
    public boolean duplicateStudentId(Students u, boolean add) {
        boolean duplicateTitle = false;
        
        connect();
        String insertQuery;
        insertQuery = (add) ? "Select student_id from tbl_students" : "Select student_id from tbl_students WHERE NOT id = ?";
        ResultSet rs = null;
        try {
            pstm = conn.prepareStatement(insertQuery);
            if(!add){
                pstm.setInt(1, u.getId());
            }
            rs = pstm.executeQuery();
            while(rs.next()){
                if(u.getStudent_id() == rs.getInt("student_id")) {
                    duplicateTitle = true;
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println("Id not found: " + e);
        }
        return duplicateTitle;
    }
}
