/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import model.Teachers;
import java.sql.*;

/**
 *
 * @author Desktop
 */
public class TeachersObjectController {
    
    private Connection conn;
    private PreparedStatement pstm;
    
    public void connect(){
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/studentrecorddb","root","");
        } catch(Exception e) {
            System.out.println("Connection failed: " + e);
        }
    }
    
    public boolean teacherRegister(Teachers u) {
        boolean isSuccessful = true;
        connect();
        String insertQuery = "INSERT INTO tbl_teachers (name, username, password) VALUES (?, ?, ?)";
        try {
            pstm = conn.prepareStatement(insertQuery);
            pstm.setString(1, u.getName());
            pstm.setString(2, u.getUsername());
            pstm.setString(3, u.getPassword());
            pstm.executeUpdate();
        } catch (Exception e) {
            System.out.println("Register failed: " + e);
            isSuccessful = false;
        }
        return isSuccessful;
    }
    
    public boolean teacherLogin(Teachers u) {
        boolean entryExists = false;
        
        connect();
        String insertQuery = "Select username, password from tbl_teachers";
        ResultSet rs = null;
        try {
            pstm = conn.prepareStatement(insertQuery);
            rs = pstm.executeQuery();
            while(rs.next()){
                if(u.getUsername().equals(rs.getString("username")) && u.getPassword().equals(rs.getString("password"))) {
                    entryExists = true;
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println("Login failed: " + e);
        }
        return entryExists;
    }
    
    public Teachers teacherInfo(Teachers u) {
        connect();
        String insertQuery = "Select * from tbl_teachers WHERE username = ?";
        ResultSet rs = null;
        try {
            pstm = conn.prepareStatement(insertQuery);
            pstm.setString(1, u.getUsername());
            rs = pstm.executeQuery();
            rs.next();
           u = new Teachers(rs.getInt("id"), rs.getString("name"), rs.getString("username"), rs.getString("password"));
        } catch (Exception e) {
            System.out.println("Display failed: " + e);
        }
        return u;
    }
}
