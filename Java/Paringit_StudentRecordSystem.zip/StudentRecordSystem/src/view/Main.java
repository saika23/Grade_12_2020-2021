/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package view;
import controller.*;
import model.*;
import java.io.*;
import java.util.*;

/**
 *
 * @author Desktop
 */
public class Main {
    public static void main(String[] args) throws Exception {
        int choice = 0;
        String choiceNum;
        int i;
        StudentsObjectController cs = new StudentsObjectController();
        TeachersObjectController ct = new TeachersObjectController();
        Students u = new Students(0, "", 0, 0);
        Teachers t = new Teachers("", "", "");
        BufferedReader br =  new BufferedReader(new InputStreamReader(System.in));
        
        
        String[] menu = {
            "Student Records\n",
            "Display All Students",
            "Display Specific Student",
            "Add Student",
            "Edit Student",
            "Delete Students",
            "Log out",
        }, labels = {
            "student",
            "Id", 
            "Student Id",
            "Name", 
            "Grade",
            "Teacher's ID"
        }, index = {
            "--------------------\n\n"
                + "Student Records\n",
            
            "Login",
            "Register",
            "Exit",
    };
        do {
            choiceNum = "";
            i = 1;
            
            for(String il : index) {
                System.out.println(choiceNum + il);
                choiceNum = "[" + i + "]";
                i++;
            }

            System.out.print("Choice: ");
            try {
                choice = Integer.parseInt(br.readLine().trim());
                System.out.println("\n" + index[choice] + "\n");
                System.out.println("--------------------\n");
            } catch (Exception e) {
                if (choice >= menu.length || choice < 0) {
                    System.out.println("Invalid choice");
                } else {
                    System.out.println("Invalid input, please use integers to select.");
                    System.out.println("Errors: " + e);
                }
                continue;
            }
            switch(choice) {
                case 1:
                    System.out.print("Username: ");
                    t.setUsername(br.readLine().trim());
                    System.out.print("Password: ");
                    t.setPassword(br.readLine().trim());
                    if(ct.teacherLogin(t)) {
                        t = ct.teacherInfo(t);
                        System.out.println("Login Successful: ");
                        do{
                            System.out.println("Teacher ID: " + t.getId());
                            choiceNum = "";
                            i = 1;
                            for(String ml : menu) {
                                System.out.println(choiceNum + ml);
                                choiceNum = "[" + i + "]"; 
                                i++;
                            }

                            System.out.print("Choice: ");
                            try {
                                choice = Integer.parseInt(br.readLine().trim());
                                System.out.println(menu[choice] + "\n");
                            } catch (Exception e) {
                                if (choice >= menu.length || choice < 0) {
                                    System.out.println("Invalid choice");
                                } else {
                                    System.out.println("Invalid input, please use integers to select.");
                                    System.out.println("Errors: " + e);
                                }
                                continue;
                            }
                            switch(choice) {

                                case 1: //display all users

                                    ArrayList<Students> entryList = cs.displayStudent(t.getId());
                                    if(!entryList.isEmpty()) {
                                        for (Students ua : entryList) {
                                            System.out.println(labels[1] + ": " + ua.getId());
                                            System.out.println(labels[2] + ": " + ua.getStudent_id());
                                            System.out.println(labels[3] + ": " + ua.getName());
                                            System.out.println(labels[4] + ": " + ua.getGrade() + "\n");
                                        }
                                    } else {
                                        System.out.println("No " + labels[0] + "s found.");
                                    }
                                    break;

                                case 2: //View Specific user
                                    try {
                                        System.out.print(labels[2] + ": ");
                                        u.setStudent_id(Integer.parseInt(br.readLine().trim()));
                                        if(!cs.StudentExists(u)) {
                                            System.out.println("No " + labels[0] + " found.");
                                            break;
                                        }
                                    } catch (Exception e) {
                                        System.out.println("Errors: " + e);
                                        break; 
                                    }
                                    Students ud = cs.displaySpecificStudent(u,t.getId());
                                    if(ud != null || ud.getId() == 0) {
                                        System.out.println(labels[1] + ": " + ud.getId());
                                        System.out.println(labels[2] + ": " + ud.getStudent_id());
                                        System.out.println(labels[3] + ": " + ud.getName());
                                        System.out.println(labels[4] + ": " + ud.getGrade() + "\n");
                                    }
                                    break;

                                case 3: //Add Item
                                    try {
                                        System.out.print(labels[2] + ": ");
                                        u.setStudent_id(Integer.parseInt(br.readLine().trim()));
                                        if(cs.duplicateStudentId(u, true)) {
                                            System.out.println(labels[2] + " is duplicated");
                                            break;
                                        }
                                        System.out.print(labels[3] + ": ");
                                        u.setName(br.readLine().trim());
                                        System.out.print(labels[4] + ": ");
                                        u.setGrade(Double.parseDouble(br.readLine().trim()));
                                    } catch (Exception e) {
                                        System.out.println("Errors: " + e);
                                        break;
                                    }
                                    if(cs.newStudent(u, t.getId())) {
                                        System.out.println("Added " + labels[0]);
                                    } else {
                                        System.out.println("Failed to add " + labels[0] + ". Teacher id does not exist");
                                    }
                                    break;

                                case 4: //edit item
                                    try {
                                        System.out.print(labels[2] + ": ");
                                        u.setStudent_id(Integer.parseInt(br.readLine().trim()));
                                        if(!cs.StudentExists(u)) {
                                            System.out.println(labels[2] + " not found");
                                            break;
                                        }
                                        System.out.print(labels[3] + ": ");
                                        u.setName(br.readLine().trim());
                                        System.out.print(labels[4] + ": ");
                                        u.setGrade(Double.parseDouble(br.readLine().trim()));
                                    } catch (Exception e) {
                                        System.out.println("Errors: " + e);
                                        break;
                                    }
                                    if(cs.editStudent(u,t.getId())) {
                                        System.out.println("Edited " + labels[3]);
                                    } else {
                                        System.out.println("Failed to edit " + labels[0]);
                                    }
                                    break;

                                case 5: //Delete Item
                                    try {
                                        System.out.print(labels[2] + ": ");
                                        u.setStudent_id(Integer.parseInt(br.readLine().trim()));
                                        if(!cs.StudentExists(u)) {
                                            System.out.println(labels[2] + " not found");
                                            break;
                                        }
                                    } catch (Exception e) {
                                        System.out.println("Errors: " + e);
                                        break;
                                    }
                                    if(cs.deleteStudent(u,t.getId())) {
                                        System.out.println("Deleted " + labels[0]);
                                    } else {
                                        System.out.println("Failed to delete " + labels[0]);
                                    }
                                    break;

                                case 6:
                                    System.out.println("Logging off");
                                    break;

                                default:
                                    System.out.println("Invalid choice");
                            }
                        } while(choice != 6);
                        break;
                    }
                    break;
                case 2: 
                    System.out.print("Name: ");
                    t.setName(br.readLine().trim());
                    System.out.print("Username: ");
                    t.setUsername(br.readLine().trim());
                    System.out.print("Password: ");
                    t.setPassword(br.readLine().trim());
                    if(ct.teacherRegister(t)) {
                        System.out.println("Registration Successful");
                    } else {
                        System.out.println("Registration Failed");
                    }
                    break;
                default:
                    System.out.println("Invalid choice");
            }
        }while(choice != 3);
    }
}
