/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.*;
import java.util.ArrayList;
import model.User;
/**
 *
 * @author Desktop
 */
public class UserObjectController {
    private PreparedStatement pstm;
    private Connection conn;
    
    
    public void establishConnection(){
        try{
            this.conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1/jdbc_db", "root", "");
        }
        catch(Exception ex){
            System.out.println("Can't establish connection. " + ex);
        }
    }
    
    public boolean addUser(User u){
        this.establishConnection();
        boolean success = false;
        
        String query = "INSERT INTO tbl_users(name, age, address) VALUES(?, ?, ?)";
        
        try{
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setInt(2, u.getAge());
            this.pstm.setString(1, u.getName());
            this.pstm.setString(3, u.getAddress());
            
            this.pstm.executeUpdate();
            success = true;
        }
        catch(Exception ex){
            System.out.println("Can't add user. " + ex);
        }
        return success;        
    }
    
    public boolean editUser(User u, int userId){
        this.establishConnection();
        boolean success = false;
        
        String query = "UPDATE tbl_users SET name = ?, age = ?, address = ? WHERE id = ?";
        
        try{
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setInt(2, u.getAge());
            this.pstm.setString(1, u.getName());
            this.pstm.setString(3, u.getAddress());
            this.pstm.setInt(4, userId);
            
            this.pstm.executeUpdate();
            success = true;
        }
        catch(Exception ex){
            System.out.println("Can't add user. " + ex);
        }
        return success; 
    }
    
    public boolean removeUser(int userId){
        this.establishConnection();
        boolean success = false;
        
        String query = "DELETE FROM tbl_users WHERE id = ?";
        
        try{
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setInt(1, userId);
            
            this.pstm.executeUpdate();
            success = true;
        }
        catch(Exception ex){
            System.out.println("Can't add user. " + ex);
        }
        return success; 
    }
    
    public ArrayList<User> viewAllUsers(){
        this.establishConnection();
        
        ArrayList<User> userList = new ArrayList<>();
        
        User u = null;
        
        ResultSet rs = null;
        
        String query = "SELECT id,name,age,address FROM tbl_users";
        
        try{
            this.pstm = this.conn.prepareStatement(query);            
            rs = this.pstm.executeQuery();
            
            while(rs.next()){
                int id = rs.getInt("id");
                String name = rs.getString(2);
                int age = rs.getInt("age");
                String address = rs.getString(4); 
                
                u = new User(id, name, age, address);                
                userList.add(u);
            }
        }
        catch(Exception ex){
            System.out.println("Can't add user. " + ex);
        }
        return userList;
    }
    
    public User viewSpecificUser(int userID){
        
        this.establishConnection();
        User u = null;
        ResultSet rs = null;
        
        String query = "SELECT * FROM tbl_users WHERE id = ?";
        
        try{
        
            this.pstm = this.conn.prepareStatement(query);
            this.pstm.setInt(1, userID);
            
            rs = this.pstm.executeQuery();
            
            if(rs.next()){
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int age = rs.getInt("age");
                String address =  rs.getString("address");

                u = new User(id, name, age, address);
            }
            
            else{
                throw new Exception("This user ID does not exist");
            }
            
        } catch(Exception ex){
            System.out.println("Cannot select user. " + ex);
        }
        
        return u;
    }
}
