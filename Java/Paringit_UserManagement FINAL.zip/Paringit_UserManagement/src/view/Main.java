/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.io.*;
import java.util.*;

import controller.UserObjectController;
import model.User;

/**
 *
 * @author Desktop
 */
public class Main {
    public static void main(String args[]) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader (System.in));
        UserObjectController uoc = new UserObjectController();
        int opt = 0;        
        
        do{
            System.out.print("--------------------\n\n");
            System.out.println("[1]View all user");//VIEW
            System.out.println("[2]Add new user");  //INSERT
            System.out.println("[3]Edit user"); //UPDATE
            System.out.println("[4]Delete user"); //DELETE
            System.out.println("[5]Exit");
            System.out.print("\nChoose an option: ");
            opt = Integer.parseInt(br.readLine());
            System.out.print("\n--------------------\n");
            
            switch(opt){
                case 1://VIEW
                    ArrayList<User> userList = uoc.viewAllUsers();
                    
                    if(userList != null){ 
                        for(User u2 : userList){
                            System.out.println("ID: " + u2.getId());
                            System.out.println("Name: " + u2.getName());
                            System.out.println("Age: " + u2.getAge());
                            System.out.println("Address: " + u2.getAddress());
                        }
                    }
                    else{
                        System.out.print("\n--------------------\n\n");
                        System.out.print("No users.\n\n"); 
                    }
                    break;
                case 2://INSERT or ADD
                    String name = "", address = "";
                    int age = 0;
                    
                    System.out.print("Enter name: ");
                    name = br.readLine();
                    System.out.print("Enter age: ");
                    age = Integer.parseInt(br.readLine());
                    System.out.print("Enter address: ");
                    address = br.readLine();
                    
                    User u = new User(name, age, address);
                                        
                    if(uoc.addUser(u) == true){
                        System.out.print("\n--------------------\n\n");
                        System.out.print("User successfully added.\n\n");                        
                    }
                    break;
                    
                case 3://UPDATE
                    int userId = 0;
                    System.out.print("Enter user ID you want update: ");
                    userId = Integer.parseInt(br.readLine()); 
                    
                    System.out.print("\nEnter new NAME: ");
                    name = br.readLine();
                    
                    System.out.print("Enter new ADDRESS: ");
                    address = br.readLine();
                    
                    System.out.print("Enter new AGE: ");
                    age = Integer.parseInt(br.readLine());
                    
                    u = new User(name, age, address);
                    
                    if(uoc.editUser(u,userId) == true){
                        System.out.print("\n--------------------\n\n");
                        System.out.print("User successfully updated.\n\n"); 
                    }
                    break;
                    
                case 4://DELETE or REMOVE
                    System.out.print("Enter user ID you want remove: ");
                    userId = Integer.parseInt(br.readLine());                   
                    
                    if(uoc.removeUser(userId)){
                        System.out.print("\n--------------------\n\n");
                        System.out.print("User successfully removed.\n\n"); 
                    }
                    break;  
                case 5:                    
                    System.out.print("Enter user id: ");
                    userId = Integer.parseInt(br.readLine()); 
                    
                    u = uoc.viewSpecificUser(userId);
                    
                    if (u != null) {
                        System.out.println("User ID: " + u.getId());
                        System.out.println("Name: " + u.getName());
                        System.out.println("Age: " + u.getAge());
                        System.out.println("Address: " + u.getAddress());
                    }
                    
                    break;
                    
            }
            
        }
        while(opt != 6);
    }
}