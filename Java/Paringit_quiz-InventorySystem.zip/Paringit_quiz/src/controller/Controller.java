/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.*;
import java.util.*;

import model.Model;
/**
 *
 * @author Desktop
 */
public class Controller {
    private Connection conn;
    private PreparedStatement pstm;
    
    public void connect(){
        try{            
            String db_src = "itemsdb";
            String db_user = "root";
            String db_pass = "";
            
            this.conn = DriverManager.getConnection("jdbc:mysql://localhost/"+db_src, db_user, db_pass);
        
        } catch(SQLException ex){
            System.out.println("Cannot Establish Connection\n"+ex);
        }
    }
    
    public boolean newEntry(Model u) {
        boolean isSuccessful = true;
        this.connect();
        
        String insertQuery = "INSERT INTO tbl_items (name, quantity, price) VALUES (?, ?, ?)";
        try {
            pstm = conn.prepareStatement(insertQuery);
            pstm.setString(1, u.getName());
            pstm.setInt(2, u.getQuantity());
            pstm.setDouble(3, u.getPrice());
            
            pstm.executeUpdate();
        } catch (Exception e) {
            System.out.println("Insert failed: " + e);
            isSuccessful = false;
        }
        return isSuccessful;
    }
    
    public boolean editEntry(Model u) {
        boolean isSuccessful = true;
        this.connect();
        String insertQuery = "UPDATE tbl_items SET name = ?, quantity = ? , price = ?, WHERE id = ?";
        try {
            pstm = conn.prepareStatement(insertQuery);
            pstm.setString(1, u.getName());
            pstm.setInt(2, u.getQuantity());
            pstm.setDouble(3, u.getPrice());
            pstm.setInt(4, u.getId());
            pstm.executeUpdate();
        } catch (Exception e) {
            System.out.println("Edit item failed: " + e);
            isSuccessful = false;
        }
        return isSuccessful;
    }
    
    public boolean deleteEntry(Model u) {
        boolean isSuccessful = true;
        connect();
        String insertQuery = "DELETE FROM tbl_items WHERE id = ?";
        try {
            pstm = conn.prepareStatement(insertQuery);
            pstm.setInt(1, u.getId());
            pstm.executeUpdate();
        } catch (Exception e) {
            System.out.println("Delete item failed: " + e);
            isSuccessful = false;
        }
        return isSuccessful;
    }
    
    public ArrayList<Model> displayItems() {
        connect();
        
        String insertQuery = "Select * from tbl_items";
        ArrayList<Model> itemList = new ArrayList();
        
        Model u = null;
        ResultSet rs = null;
        try {
            pstm = conn.prepareStatement(insertQuery);
            rs = pstm.executeQuery();
            while(rs.next()) {
                u = new Model(rs.getInt("id"), rs.getString("name"), rs.getInt("quantity"), rs.getDouble("price"));
                itemList.add(u);
            }
        } catch (Exception e) {
            System.out.println("Display failed: " + e);
        }
        return itemList;
    }
    
    public Model displaySpecificItem(Model u) {
        connect();
        
        String insertQuery = "Select * from tbl_items WHERE id = ?";
        ResultSet rs = null;
        try {
            pstm = conn.prepareStatement(insertQuery);
            pstm.setInt(1, u.getId());
            rs = pstm.executeQuery();
            rs.next();
            u = new Model (rs.getInt("id"), rs.getString("name"), rs.getInt("quantity"), rs.getDouble("price"));
        } catch (Exception e) {
            System.out.println("Item failed: "  + e);
        }
        return u;
    }
    
    public boolean itemExists (Model u) {
        boolean itemExists = false;
        
        connect();
        String insertQuery = "Select id from tbl_items";
        ResultSet rs = null;
        try {
            pstm = conn.prepareStatement(insertQuery);
            rs = pstm.executeQuery();
            while(rs.next()){
                if(u.getId() == rs.getInt("id")) {
                    itemExists = true;
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println("Id not found: " + e);
        }
        return itemExists;
    }
}